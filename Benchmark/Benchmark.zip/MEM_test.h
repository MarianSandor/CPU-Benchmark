#ifndef MEM_TEST_H
#define MEM_TEST_H

#include <windows.h>
#include <sys\timeb.h> 
#include <iostream>
#include <fstream>

int MEM_run_test();

#endif
