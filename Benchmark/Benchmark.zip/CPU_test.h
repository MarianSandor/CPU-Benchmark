#ifndef CPU_TEST_H
#define CPU_TEST_H

#include <windows.h>
#include <sys\timeb.h> 
#include "gzip.h"
#include <time.h>
#include <iostream>
#include <fstream>


int CPU_run_test();

#endif
